# Boutique Changelog

### *2015.04.30* - 1.1.2
* **Fix** - Cart icon on handheld view.

### *2015.03.31* - 1.1.1
* **Fix** - Broken documentation link in readme.
* **Fix** - Site header margin when using shop page as homepage.
* **Tweak** - Improved contrast of default link color.

### *2015.02.20* - 1.1.0
* **New** - Integration with Storefront Product Hero.
* **Tweak** - Featured product treatment.
* **Tweak** - Improvements to display on tablets in portrait orientation.
* **Fix** - Header widget region background.
* **Fix** - Navigation padding.
* **Fix** - WooCommerce Customiser extension compatibility.
* **Fix** - Storefront 1.3.0 compatibility.

### *2015.01.20* - 1.0.0
* Initial release!