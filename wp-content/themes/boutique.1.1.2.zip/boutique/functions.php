<?php
/**
 * Boutique engine room
 *
 * @package storefront
 */

/**
 * Initialize all the things.
 */
require get_stylesheet_directory() . '/inc/init.php';