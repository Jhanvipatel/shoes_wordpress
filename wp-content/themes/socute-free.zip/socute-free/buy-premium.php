<?php

return array(
    'slug' => 'socute',
    'url' => 'https://yithemes.com/themes/wordpress/socute-multi-purpose-e-commerce-theme/?utm_source=yith-panel&utm_medium=wpadmin&utm_content=banner-upgrade-socute&utm_campaign=yith-admin',

    //'price' => ''   // default price, if any response from remote
    //'img' => YIT_CORE_URL .'/assets/images/buy-premium.png'   // banner image
);
