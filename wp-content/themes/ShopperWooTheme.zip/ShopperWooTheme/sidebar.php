		<div id="sidebar">
		
			<?php if( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Sidebar') ) : ?>
			
			<div class="side_box">
				
			</div><!--//side_box-->
			
			<?php endif; ?>
			
		</div><!--//sidebar-->