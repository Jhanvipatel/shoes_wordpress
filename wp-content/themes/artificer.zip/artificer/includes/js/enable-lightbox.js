jQuery( document ).ready( function ( e ) {
	jQuery( 'a[rel^="lightbox"], .woocommerce .images a' ).prettyPhoto({social_tools: false});
});